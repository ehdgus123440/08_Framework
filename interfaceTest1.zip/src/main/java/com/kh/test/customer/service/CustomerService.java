package com.kh.test.customer.service;

import com.kh.test.customer.dto.Customer;

public interface CustomerService {
  int insertCustomer(Customer customer);
}
